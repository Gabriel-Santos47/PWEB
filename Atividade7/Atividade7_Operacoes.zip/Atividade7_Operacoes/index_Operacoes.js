var num1 = parseFloat(prompt('Informe o 1ª Número: '));
var num2 = parseFloat(prompt('Informe o 2ª Número: '));

var soma = num1 + num2;
var sub = num1 - num2;
var produto = num1 * num2;
var div = num1 / num2;
var mod = num1 % num2;

alert("a Soma é " + soma.toFixed(2));
alert("a Subtração é" + sub.toFixed(2));
alert("a Multiplicação é " + produto.toFixed(2));
alert(" Divisão é " + div.toFixed(2));
alert("o Resto é " + mod.toFixed(2));

