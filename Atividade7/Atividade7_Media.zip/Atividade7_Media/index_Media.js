var nota1 = parseFloat(prompt('Digite a 1ª Nota: '));
var nota2 = parseFloat(prompt('Digite a 2ª Nota: '));
var nota3 = parseFloat(prompt('Digite a 3ª Nota: '));


function calcularMedia(){
var media = (nota1 + nota2 + nota3)/3;
return media

}

var media = calcularMedia();
alert('A sua media é :' + media.toFixed(2));