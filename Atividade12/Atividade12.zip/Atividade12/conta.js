
        function Conta() {
            var nomeCorrentista;
            var banco;
            var numeroConta;
            var saldo;
            //
            this.setNomeCorrentista = function (value) {
                this.nomeCorrentista = value;
            }
            this.getNomeCorrentista = function () {
                return this.nomeCorrentista;
            }
            //
            this.setBanco = function (value) {
                this.banco = value;
            }
            this.getBanco = function () {
                return this.banco;
            }
            //
            this.setNumeroConta = function (value) {
                this.numeroConta = value;
            }
            this.getNumeroConta = function () {
                return this.numeroConta;
            } 
            //
            this.setSaldo = function (value) {
                this.saldo = value;
            }
            this.getSaldo = function () {
                return this.saldo;
            } 
        }
            var conta = new Conta();
 
            conta.setNomeCorrentista("Gabriel");
            conta.setBanco("Itaú");
            conta.setNumeroConta("4021");
            conta.setSaldo(1000);
           
 
        //Corrente
        function Corrente() {
            var saldoEspecial;
 
            this.setSaldoEspecial = function (value) {
                this.saldoEspecial = value;
            }
            this.getSaldoEspecial = function () {
                return this.saldoEspecial;
            }
        }
            Corrente.prototype = new Conta();
            var corrente = new Corrente();
 
            corrente.setSaldoEspecial(100);
            alert(" - Corrente - ");
            alert("NomeCorrentista = " + conta.getNomeCorrentista() + " Banco = " + conta.getBanco()+ " NumeroConta = " +
            conta.getNumeroConta()  + " Saldo = " + conta.getSaldo() + " SaldoEspecial = " + corrente.getSaldoEspecial());
        
        //Poupança
        function Poupanca() {
            var juros;
            var dataVencimento;
 
            this.setJuros = function (value) {
                this.juros = value;
            }
            this.getJuros = function () {
                return this.juros;
            }
            //
            this.setDataVencimento = function (value) {
                this.dataVencimento = value;
            }
            this.getDataVencimento = function () {
                return this.dataVencimento;
            }
        }
 
            Poupanca.prototype = new Conta();
            var poupanca = new Poupanca();
 
            poupanca.setJuros(100);
            poupanca.setDataVencimento("22-05-2024");
            alert("  - Poupança -  ")
            alert("NomeCorrentista = " + conta.getNomeCorrentista() + " Banco = " + conta.getBanco()+ " NumeroConta = " +
            conta.getNumeroConta()  + " Saldo = " + conta.getSaldo() + " Juros = " + poupanca.getJuros() +" %" + " DataVencimento = "  + poupanca.getDataVencimento());
        