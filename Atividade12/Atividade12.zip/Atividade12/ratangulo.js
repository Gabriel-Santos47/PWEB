function Retangulo(altura,lado){
    this.altura = altura;
    this.lado = lado;
     
    this.MostraResult = function(){
    var result =  2 * (altura + lado);
    return "Altura = " + this.altura + "Lado = " + this.lado + " Area = " + result ;
    }
    };
     
    var calcular = new Retangulo(10,5);
    alert(calcular.MostraResult());